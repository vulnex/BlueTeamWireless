# Student Quick Start Guide
## Wireless Security Workshop - Detection Lab

---

## ⚠️ Important: Use `sudo` for all Docker commands!

---

## 🚀 5-Minute Setup

### Step 1: Start the Container

```bash
cd /path/to/nzyme-docker
sudo docker compose up -d
```

### Step 2: Enter the Container

```bash
sudo docker exec -it nzyme-workshop bash
```

### Step 3: Set Up Your WiFi Adapter

```bash
# Check your adapter is visible
iw dev

# Enable monitor mode (replace with your adapter name)
airmon-ng check kill
airmon-ng start wlx00c0ca8fd66c

# Verify - should show wlan0mon
iw dev
```

### Step 4: Open the Web UIs

| Tool | URL | Login |
|------|-----|-------|
| **Nzyme** | https://localhost:22900 | Create account |
| **Kismet** | http://localhost:2501 | kismet / kismet |

---

## ⚠️ Single Adapter: Run ONE Tool at a Time!

Kismet and Nzyme cannot share the same wireless adapter simultaneously. Follow this sequence:

---

## 📡 PART 1: Kismet IDS (First Half)

### Start Kismet
```bash
supervisorctl start kismet
```

### Verify Kismet is Running
- Open http://localhost:2501
- Login: `kismet` / `kismet`
- Check Data Sources shows your adapter

### 🔍 Kismet Detection Exercise

Watch for these alerts during instructor attacks:

| Attack | Kismet Alert | Detected? |
|--------|-------------|-----------|
| Deauth Flood | `DEAUTHFLOOD` | ☐ |
| Evil Twin | `APSPOOF` | ☐ |
| Beacon Flood | Multiple new APs | ☐ |

### Stop Kismet When Done
```bash
supervisorctl stop kismet
```

---

## 🔄 SWITCHING TOOLS

```bash
# Verify Kismet is stopped
supervisorctl status

# Monitor mode stays active - no need to redo airmon-ng
iw dev  # Should still show wlan0mon
```

---

## 📡 PART 2: Nzyme IDS (Second Half)

### Configure Nzyme Tap (First Time Only)

1. Open https://localhost:22900
2. Create admin account
3. Go to **System → Taps → Add Tap**
4. Copy the **Tap Secret**
5. Edit config inside container:
```bash
nano /etc/nzyme/nzyme-tap.conf
```

6. Update these values:
```toml
[general]
leader_secret = "PASTE_YOUR_TAP_SECRET_HERE"

[wifi_interfaces.wlan0mon]
active = true
```

**Note:** If your interface has a different name, rename the section:
```toml
[wifi_interfaces.YOUR_INTERFACE_NAME]
active = true
```

### Start Nzyme Tap
```bash
supervisorctl start nzyme-tap
```

### Verify Nzyme is Running
- Check https://localhost:22900
- Navigate to **System → Taps** - should show tap online
- Go to **WiFi → Overview** to see detected networks

### 🔍 Nzyme Detection Exercise

Watch for these alerts during instructor attacks:

| Attack | Nzyme Alert | Detected? |
|--------|-------------|-----------|
| Deauth Flood | Deauthentication detected | ☐ |
| Evil Twin | Unexpected BSSID for SSID | ☐ |
| Karma Attack | Bandit detected | ☐ |

### Stop Nzyme When Done
```bash
supervisorctl stop nzyme-tap
```

---

## 🔧 Essential Commands

```bash
# Check service status
supervisorctl status

# View logs
tail -f /var/log/supervisor/kismet.log
tail -f /var/log/nzyme/nzyme-tap.log

# Quick channel change
iw dev wlan0mon set channel 6

# Capture packets for analysis
tcpdump -i wlan0mon -w /opt/workshop/captures/mytest.pcap
```

---

## 🆘 Troubleshooting

**"Interface busy" or tool won't start?**
```bash
# Make sure the other tool is stopped
supervisorctl stop kismet
supervisorctl stop nzyme-tap

# Check status
supervisorctl status
```

**Lost monitor mode?**
```bash
airmon-ng check kill
airmon-ng start wlan0  # or your adapter name
```

**Need help?** Raise your hand! 🙋

---

## 📝 Notes Space

_Use this area to record observations during the workshop:_

```
KISMET OBSERVATIONS:

Attack 1 (Deauth):


Attack 2 (Evil Twin):



NZYME OBSERVATIONS:

Attack 1 (Deauth):


Attack 2 (Evil Twin):



COMPARISON - Which tool detected better?


```
