#!/bin/bash
# ============================================================================
# Health Check Script
# Blue Team Wireless Security Workshop
# ============================================================================

# Check PostgreSQL
if ! pg_isready -q; then
    echo "PostgreSQL is not ready"
    exit 1
fi

# Check if Nzyme node port is listening
if ! nc -z localhost 22900 2>/dev/null; then
    echo "Nzyme node is not responding on port 22900"
    exit 1
fi

# All checks passed
echo "OK"
exit 0
