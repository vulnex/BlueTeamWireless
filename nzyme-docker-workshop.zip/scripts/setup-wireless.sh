#!/bin/bash
# ============================================================================
# Wireless Interface Setup Script
# Blue Team Wireless Security Workshop
# 
# Usage: ./setup-wireless.sh [interface]
# Example: ./setup-wireless.sh wlan0
# ============================================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() { echo -e "${GREEN}[INFO]${NC} $1"; }
log_warn() { echo -e "${YELLOW}[WARN]${NC} $1"; }
log_error() { echo -e "${RED}[ERROR]${NC} $1"; }

# ============================================================================
# Check if running as root
# ============================================================================
if [ "$EUID" -ne 0 ]; then
    log_error "Please run as root (use sudo)"
    exit 1
fi

# ============================================================================
# List available interfaces if no argument provided
# ============================================================================
if [ -z "$1" ]; then
    echo ""
    echo "Available wireless interfaces:"
    echo "=============================="
    iw dev 2>/dev/null | grep -E "Interface|type" | sed 'N;s/\n/ /' || echo "No wireless interfaces found"
    echo ""
    echo "Usage: $0 <interface>"
    echo "Example: $0 wlan0"
    echo ""
    exit 0
fi

INTERFACE=$1
MONITOR_INTERFACE="${INTERFACE}mon"

# ============================================================================
# Check if interface exists
# ============================================================================
if ! ip link show "$INTERFACE" &>/dev/null; then
    # Maybe it's already in monitor mode
    if ip link show "$MONITOR_INTERFACE" &>/dev/null; then
        log_info "$MONITOR_INTERFACE already exists and is in monitor mode"
        log_info "Ready to use!"
        exit 0
    fi
    log_error "Interface $INTERFACE not found"
    exit 1
fi

# ============================================================================
# Check if interface supports monitor mode
# ============================================================================
log_info "Checking if $INTERFACE supports monitor mode..."

PHY=$(iw dev "$INTERFACE" info 2>/dev/null | grep wiphy | awk '{print "phy"$2}')
if [ -z "$PHY" ]; then
    log_error "Could not determine physical device for $INTERFACE"
    exit 1
fi

if iw phy "$PHY" info | grep -q "monitor"; then
    log_info "$INTERFACE supports monitor mode"
else
    log_error "$INTERFACE does not support monitor mode"
    log_error "You need a compatible adapter (Atheros, Ralink, Realtek RTL8812AU, etc.)"
    exit 1
fi

# ============================================================================
# Kill interfering processes
# ============================================================================
log_info "Killing interfering processes..."
airmon-ng check kill 2>/dev/null || true

# ============================================================================
# Enable monitor mode
# ============================================================================
log_info "Enabling monitor mode on $INTERFACE..."

# Method 1: Try airmon-ng first
if airmon-ng start "$INTERFACE" 2>/dev/null; then
    log_info "Monitor mode enabled via airmon-ng"
else
    # Method 2: Manual method
    log_warn "airmon-ng failed, trying manual method..."
    
    ip link set "$INTERFACE" down
    iw dev "$INTERFACE" set type monitor
    ip link set "$INTERFACE" up
    
    # Rename to standard naming convention
    if [ "$INTERFACE" != "$MONITOR_INTERFACE" ]; then
        ip link set "$INTERFACE" name "$MONITOR_INTERFACE" 2>/dev/null || true
    fi
    
    log_info "Monitor mode enabled manually"
fi

# ============================================================================
# Verify monitor mode
# ============================================================================
sleep 1

# Find the monitor interface (might be renamed)
ACTUAL_MON=$(iw dev 2>/dev/null | grep -B1 "type monitor" | grep Interface | awk '{print $2}' | head -1)

if [ -z "$ACTUAL_MON" ]; then
    log_error "Failed to enable monitor mode"
    exit 1
fi

log_info "Monitor mode interface: $ACTUAL_MON"

# ============================================================================
# Test packet capture
# ============================================================================
log_info "Testing packet capture..."
PACKET_COUNT=$(timeout 3 tcpdump -i "$ACTUAL_MON" -c 5 2>/dev/null | wc -l || echo "0")

if [ "$PACKET_COUNT" -gt 0 ]; then
    log_info "Packet capture working! Captured packets in 3 seconds."
else
    log_warn "No packets captured in test. This might be normal if no traffic nearby."
fi

# ============================================================================
# Update configuration files
# ============================================================================
echo ""
log_info "Updating configuration files..."

# Update Kismet config
if [ -f /etc/kismet/kismet_site.conf ]; then
    # Check if source already defined
    if grep -q "^source=" /etc/kismet/kismet_site.conf; then
        sed -i "s/^source=.*/source=$ACTUAL_MON:name=workshop_monitor/" /etc/kismet/kismet_site.conf
    else
        echo "source=$ACTUAL_MON:name=workshop_monitor" >> /etc/kismet/kismet_site.conf
    fi
    log_info "Updated Kismet config with source=$ACTUAL_MON"
fi

# Update Nzyme tap config
if [ -f /etc/nzyme/nzyme-tap.conf ]; then
    sed -i "s/^interface = \".*\"/interface = \"$ACTUAL_MON\"/" /etc/nzyme/nzyme-tap.conf
    log_info "Updated Nzyme tap config with interface=$ACTUAL_MON"
fi

# ============================================================================
# Summary
# ============================================================================
echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║              WIRELESS SETUP COMPLETE                           ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  Monitor Interface: $ACTUAL_MON"
echo "║  Status: Ready for capture                                     ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  Next Steps:                                                   ║"
echo "║  1. Configure Nzyme tap secret in /etc/nzyme/nzyme-tap.conf    ║"
echo "║  2. Start services:                                            ║"
echo "║     supervisorctl start kismet                                 ║"
echo "║     supervisorctl start nzyme-tap                              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# ============================================================================
# Show current channel
# ============================================================================
CHANNEL=$(iw dev "$ACTUAL_MON" info 2>/dev/null | grep channel | awk '{print $2}')
if [ -n "$CHANNEL" ]; then
    log_info "Current channel: $CHANNEL"
    log_info "To change channel: iw dev $ACTUAL_MON set channel <num>"
fi

exit 0
