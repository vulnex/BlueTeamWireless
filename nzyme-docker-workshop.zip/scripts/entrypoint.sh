#!/bin/bash
# ============================================================================
# Nzyme Docker Entrypoint Script
# Blue Team Wireless Security Workshop
# ============================================================================

set -e

echo "=============================================="
echo " Nzyme Wireless IDS Workshop Container"
echo "=============================================="
echo ""

# ============================================================================
# Color Output
# ============================================================================
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_section() {
    echo -e "${BLUE}==== $1 ====${NC}"
}

# ============================================================================
# Initialize PostgreSQL
# ============================================================================
log_section "Initializing PostgreSQL"

# Detect and export PostgreSQL version
export PG_VERSION=$(ls /etc/postgresql/ 2>/dev/null | head -1 || echo "17")
log_info "PostgreSQL version: $PG_VERSION"

# Start PostgreSQL
service postgresql start
sleep 3

# Verify PostgreSQL is running
if pg_isready -q; then
    log_info "PostgreSQL is running"
else
    log_error "PostgreSQL failed to start"
    exit 1
fi

# ============================================================================
# Initialize Nzyme Database
# ============================================================================
log_section "Initializing Nzyme Database"

# Run database migrations if this is first run
if [ ! -f /var/lib/nzyme/.db_initialized ]; then
    log_info "Running Nzyme database migrations..."
    
    # Run migrate command
    cd /opt/nzyme
    if /usr/bin/nzyme --migrate-database 2>/dev/null || java -jar /opt/nzyme/nzyme-node.jar --migrate-database -c /etc/nzyme/nzyme.conf 2>/dev/null; then
        log_info "Database migration completed"
        touch /var/lib/nzyme/.db_initialized
    else
        log_warn "Migration command may have different syntax, proceeding anyway..."
        touch /var/lib/nzyme/.db_initialized
    fi
else
    log_info "Database already initialized"
fi

# ============================================================================
# Detect Wireless Interfaces
# ============================================================================
log_section "Detecting Wireless Interfaces"

# List available wireless interfaces
echo ""
echo "Available network interfaces:"
ip link show | grep -E "^[0-9]+:" | awk '{print $2}' | tr -d ':'
echo ""

# Check for wireless interfaces
WIFI_INTERFACES=$(iw dev 2>/dev/null | grep Interface | awk '{print $2}' || echo "")

if [ -z "$WIFI_INTERFACES" ]; then
    log_warn "No wireless interfaces detected!"
    log_warn "Make sure to:"
    log_warn "  1. Connect a USB WiFi adapter to the host"
    log_warn "  2. Pass it to Docker with --device or --privileged"
    echo ""
    log_info "Example: docker run --privileged -v /dev/bus/usb:/dev/bus/usb ..."
else
    log_info "Detected wireless interfaces:"
    for iface in $WIFI_INTERFACES; do
        echo "  - $iface"
        
        # Check if already in monitor mode
        if iw dev $iface info 2>/dev/null | grep -q "type monitor"; then
            log_info "  $iface is already in monitor mode"
        else
            log_info "  $iface is in managed mode (needs to be set to monitor mode)"
        fi
    done
fi

echo ""
log_info "To set an interface to monitor mode, run inside container:"
echo "  airmon-ng check kill"
echo "  airmon-ng start <interface>"
echo ""

# ============================================================================
# Create TLS Directories
# ============================================================================
log_section "Setting up TLS"

mkdir -p /var/lib/nzyme/tls
chmod 700 /var/lib/nzyme/tls

# ============================================================================
# Display Access Information
# ============================================================================
log_section "Access Information"

echo ""
echo "╔════════════════════════════════════════════════════════════════╗"
echo "║                    WORKSHOP ACCESS URLS                        ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  Nzyme Web UI:       https://localhost:22900                   ║"
echo "║  Kismet Web UI:      http://localhost:2501                     ║"
echo "║  Supervisor:         http://localhost:9001                     ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  Kismet Login:       kismet / kismet                           ║"
echo "║  Supervisor Login:   admin / workshop                          ║"
echo "╠════════════════════════════════════════════════════════════════╣"
echo "║  NOTE: Nzyme creates admin user on first access                ║"
echo "║        Accept the self-signed certificate warning              ║"
echo "╚════════════════════════════════════════════════════════════════╝"
echo ""

# ============================================================================
# Quick Start Instructions
# ============================================================================
log_section "Quick Start Instructions"

echo ""
echo "1. SETUP MONITOR MODE (inside container):"
echo "   docker exec -it nzyme-workshop bash"
echo "   airmon-ng check kill"
echo "   airmon-ng start wlan0"
echo ""
echo "2. CONFIGURE NZYME TAP:"
echo "   a. Open Nzyme web UI and create admin account"
echo "   b. Go to System > Taps > Add Tap"
echo "   c. Copy the Tap Secret"
echo "   d. Edit /etc/nzyme/nzyme-tap.conf with the secret"
echo "   e. supervisorctl start nzyme-tap"
echo ""
echo "3. START KISMET:"
echo "   supervisorctl start kismet"
echo ""
echo "4. USEFUL COMMANDS:"
echo "   supervisorctl status          # Check service status"
echo "   supervisorctl restart <svc>   # Restart a service"
echo "   tail -f /var/log/nzyme/*.log  # View logs"
echo ""

# ============================================================================
# Start Supervisor (Main Process)
# ============================================================================
log_section "Starting Services"
log_info "Starting Supervisor..."
echo ""

# Execute the main command (supervisord)
exec "$@"
