# Nzyme Wireless IDS Docker Workshop Environment

## Blue Team Wireless Security Workshop

This Docker setup provides a complete wireless intrusion detection environment for training purposes, combining:

- **Nzyme 2.x** (node + tap) - WiFi defense system
- **Kismet** - Wireless network detector and IDS
- **Aircrack-ng** - Wireless security toolkit
- **tshark/Wireshark** - Packet analysis

---

## ⚠️ CRITICAL: Docker Engine Required (NOT Docker Desktop!)

**Docker Desktop will NOT work** for wireless capture — it runs containers in a VM that can't access USB WiFi adapters.

You must use **native Docker Engine** on Linux:

```bash
# Install Docker Engine (if you have Docker Desktop, remove it first)
sudo apt update
sudo apt install docker.io docker-compose-v2

# Add yourself to docker group
sudo usermod -aG docker $USER
# Log out and back in

# Verify
docker --version
```

**All commands must use `sudo`** (or run as root) for wireless access:
```bash
sudo docker compose build
sudo docker compose up -d
sudo docker exec -it nzyme-workshop bash
```

---

## Prerequisites

### Host System Requirements

| Component | Minimum | Recommended |
|-----------|---------|-------------|
| OS | Linux (Ubuntu 22.04+, Debian 12+, Kali) | Native Linux (not VM) |
| RAM | 4 GB | 8 GB |
| CPU | 2 cores | 4 cores |
| Disk | 10 GB free | 20 GB free |
| Docker | Docker Engine 20.10+ | **NOT Docker Desktop** |

### USB WiFi Adapter

You need a USB WiFi adapter that supports **monitor mode**. Recommended chipsets:

| Chipset | Adapter Examples | 2.4 GHz | 5 GHz | Monitor Mode |
|---------|------------------|---------|-------|--------------|
| Atheros AR9271 | Alfa AWUS036NHA | ✅ | ❌ | ✅ Excellent |
| Ralink RT3070 | Alfa AWUS036NH | ✅ | ❌ | ✅ Excellent |
| Realtek RTL8812AU | Alfa AWUS036ACH | ✅ | ✅ | ✅ Good |
| Realtek RTL8814AU | Alfa AWUS1900 | ✅ | ✅ | ✅ Good |
| MediaTek MT7612U | Panda PAU09 | ✅ | ✅ | ✅ Good |

⚠️ **Internal laptop WiFi cards usually don't support monitor mode properly.**

---

## Quick Start

### 1. Clone/Download the Project

```bash
cd /path/to/workshop
unzip nzyme-docker-workshop.zip
cd nzyme-docker
```

### 2. Build the Docker Image

```bash
# MUST use sudo for wireless access
sudo docker compose build
```

Build time: ~5-10 minutes depending on internet speed.

### 3. Connect Your WiFi Adapter

Plug in your USB WiFi adapter to the **host machine**.

Verify it's detected:
```bash
# Install iw if needed
sudo apt install iw wireless-tools

# Check adapter is visible
iw dev
lsusb | grep -i wireless
```

### 4. Start the Container

```bash
# MUST use sudo
sudo docker compose up -d

# Check it's running
sudo docker ps
```

### 5. Access the Container

```bash
sudo docker exec -it nzyme-workshop bash
```

### 6. Set Up Wireless Interface

Inside the container:

```bash
# List available interfaces
iw dev

# Enable monitor mode on your USB adapter
airmon-ng check kill
airmon-ng start wlx<your_adapter_name>
# Or if the name is short enough:
# airmon-ng start wlan0

# Verify monitor mode (should show wlan0mon or similar)
iw dev
```

### 7. Access Web Interfaces

| Service | URL | Credentials |
|---------|-----|-------------|
| Nzyme | https://localhost:22900 | Create on first access |
| Kismet | http://localhost:2501 | kismet / kismet |
| Supervisor | http://localhost:9001 | admin / workshop |

⚠️ Accept the self-signed certificate warning for Nzyme.

---

## Detailed Configuration

### Nzyme Setup

#### Step 1: Create Admin Account

1. Open https://localhost:22900
2. Accept the certificate warning
3. Create your admin account
4. Enable MFA (recommended)

#### Step 2: Create a Tap

1. Navigate to: **System → Taps → Add Tap**
2. Select Organization: Default
3. Select Tenant: Default
4. Give it a name: "workshop-tap-01"
5. Click **Create Tap**
6. **Copy the Tap Secret** (you'll need this!)

#### Step 3: Configure the Tap

Inside the container:
```bash
nano /etc/nzyme/nzyme-tap.conf
```

Update the `leader_secret` in the `[general]` section:
```toml
[general]
leader_secret = "PASTE_YOUR_TAP_SECRET_HERE"
leader_uri = "https://127.0.0.1:22900/"
accept_insecure_certs = true
```

If your monitor interface has a different name than `wlan0mon`, rename the wifi section:
```toml
# Change [wifi_interfaces.wlan0mon] to match your interface:
[wifi_interfaces.YOUR_INTERFACE_NAME]
active = true
channel_width_hopping_mode = "limited"
channels_2g = [1, 6, 11]
channels_5g = []
channels_6g = []
```

#### Step 4: Start the Tap

```bash
# Start via supervisor
supervisorctl start nzyme-tap

# Or run directly to see output
nzyme-tap -c /etc/nzyme/nzyme-tap.conf
```

#### Step 5: Configure Monitored Networks

1. In Nzyme UI: **WiFi → Monitoring → Add SSID**
2. Enter your target network details:
   - SSID name
   - Expected BSSIDs
   - Expected channels
   - Expected security (WPA2, etc.)

### Kismet Setup

#### Start Kismet

```bash
supervisorctl start kismet
```

#### Configure Data Source

Edit `/etc/kismet/kismet_site.conf`:
```conf
source=wlan0mon:name=workshop_monitor
```

Then restart:
```bash
supervisorctl restart kismet
```

---

## Workshop Commands Cheat Sheet

### Service Management

```bash
# Check status of all services
supervisorctl status

# Start/stop/restart services
supervisorctl start kismet
supervisorctl stop nzyme-tap
supervisorctl restart nzyme-node

# View logs
tail -f /var/log/nzyme/nzyme-node.log
tail -f /var/log/nzyme/nzyme-tap.log
tail -f /var/log/supervisor/kismet.log
```

### Wireless Commands

```bash
# List wireless interfaces
iw dev

# Check interface details
iw dev wlan0mon info

# Change channel
iw dev wlan0mon set channel 6

# Quick packet capture test
tcpdump -i wlan0mon -c 10

# Capture to file
tcpdump -i wlan0mon -w /opt/workshop/captures/test.pcap
```

### Aircrack-ng Commands

```bash
# Scan for networks
airodump-ng wlan0mon

# Target specific network
airodump-ng -c 6 --bssid AA:BB:CC:DD:EE:FF wlan0mon

# Capture handshakes (for authorized testing only!)
airodump-ng -c 6 --bssid AA:BB:CC:DD:EE:FF -w capture wlan0mon
```

### Analysis Commands

```bash
# Read pcap with tshark
tshark -r /opt/workshop/captures/test.pcap

# Filter for deauth frames
tshark -r capture.pcap -Y "wlan.fc.type_subtype == 0x0c"

# Filter for beacons
tshark -r capture.pcap -Y "wlan.fc.type_subtype == 0x08"

# Show SSIDs
tshark -r capture.pcap -Y "wlan.fc.type_subtype == 0x08" -T fields -e wlan.ssid
```

---

## Troubleshooting

### "No wireless interfaces found"

**Cause:** USB adapter not passed through to container.

**Solution:**
```bash
# On host, verify adapter is detected
lsusb | grep -i wireless

# Restart container with USB passthrough
docker-compose down
docker-compose up -d

# Or add --privileged and -v /dev/bus/usb:/dev/bus/usb
```

### "Monitor mode failed"

**Cause:** Interface busy or driver issue.

**Solution:**
```bash
# Kill interfering processes
airmon-ng check kill

# Bring interface down first
ip link set wlan0 down
iw dev wlan0 set type monitor
ip link set wlan0 up
```

### "Nzyme node won't start"

**Cause:** Database or configuration issue.

**Solution:**
```bash
# Check logs
tail -50 /var/log/nzyme/nzyme-node.log

# Verify PostgreSQL is running
pg_isready

# Restart PostgreSQL
supervisorctl restart postgresql
sleep 5
supervisorctl restart nzyme-node
```

### "Nzyme tap won't connect"

**Cause:** Wrong secret or network issue.

**Solution:**
```bash
# Verify config
grep leader_secret /etc/nzyme/nzyme-tap.conf

# Verify node is accessible
curl -k https://localhost:22900

# Check tap logs
tail -50 /var/log/nzyme/nzyme-tap.log
```

### "Kismet shows no devices"

**Cause:** No data source configured.

**Solution:**
```bash
# Check if source is defined
grep "^source=" /etc/kismet/kismet_site.conf

# Add source
echo "source=wlan0mon:name=workshop" >> /etc/kismet/kismet_site.conf

# Restart Kismet
supervisorctl restart kismet
```

---

## Port Reference

| Port | Service | Protocol |
|------|---------|----------|
| 22900 | Nzyme Web UI | HTTPS |
| 2501 | Kismet Web UI | HTTP |
| 9001 | Supervisor Web UI | HTTP |
| 5432 | PostgreSQL | TCP (internal) |

---

## File Locations

| Path | Purpose |
|------|---------|
| `/etc/nzyme/nzyme.conf` | Nzyme node configuration |
| `/etc/nzyme/nzyme-tap.conf` | Nzyme tap configuration |
| `/etc/kismet/kismet_site.conf` | Kismet configuration |
| `/var/log/nzyme/` | Nzyme logs |
| `/opt/kismet/logs/` | Kismet logs and captures |
| `/opt/workshop/captures/` | Your capture files |

---

## Security Notes

⚠️ **This is a workshop environment, not production-ready!**

- Default passwords are set for convenience
- Self-signed certificates are used
- Privileged mode grants full host access
- Only use on isolated lab networks

For production deployment, consult the official Nzyme documentation.

---

## Resources

- [Nzyme Documentation](https://docs.nzyme.org/)
- [Kismet Documentation](https://www.kismetwireless.net/docs/)
- [Aircrack-ng Wiki](https://www.aircrack-ng.org/documentation.html)

---

## License

This workshop configuration is provided for educational purposes.

- Nzyme: SSPL License
- Kismet: GPL v2
- Aircrack-ng: GPL v2
